GITHUB PAGES VERSION

This version is static and can be hosted directly with GitHub Pages.

1. Create a GitHub repository.
2. Upload index.html.
3. Go to Settings > Pages.
4. Under Build and deployment, choose "Deploy from a branch".
5. Select the main branch and "/" folder.
6. Save.

Your site will be:
https://YOUR-USERNAME.github.io/REPOSITORY-NAME/

IMPORTANT:
GitHub Pages cannot run Node/Express or SQLite. This version therefore stores submissions in the visitor's browser using localStorage. That means it is a working static demo, but submissions are NOT shared between different users/devices.

The staff login in this static version is also NOT secure because GitHub Pages sends the JavaScript to every visitor. Do not use real staff credentials with this version.

For a real production version with shared tickets, secure staff authentication, Discord webhooks, and a database, a backend/database is required.
